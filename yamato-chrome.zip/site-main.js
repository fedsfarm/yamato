// Site adapters; see CONTRIBUTING.md.
globalThis.yamatoSites = (() => {
  const definitions = [
    ...[
      ['google', 'Google', ['google.com', 'google.co.uk', 'google.de', 'google.fr', 'google.se', 'google.ca', 'google.com.au', 'google.co.in', 'google.co.jp'], '[data-docid], [data-lpage], .isv-r, .g, [data-ved][data-hveid]:has([role="link"]), a:has(img)'],
      ['bing', 'Bing', ['bing.com'], '.iusc, .b_algo, .imgpt, a:has(img)'],
      ['duckduckgo', 'DuckDuckGo', ['duckduckgo.com'], '.tile--img, .result, [data-testid="result"], [data-testid="image-result"], [data-testid="zci-images"] figure, .XkLPXSx75VKPFICzKfew, .ARegRZbMqxI9JfJA__kH, a:has(img)'],
      ['brave', 'Brave', ['search.brave.com'], '.snippet, .image-result, [data-type="image"], a:has(img)'],
      ['yahoo', 'Yahoo', ['search.yahoo.com'], '.res, .ld, .imgres, a:has(img)'],
      ['yandex', 'Yandex', ['yandex.com', 'yandex.ru'], '.SerpItem, .serp-item, .Organic, a:has(img)'],
    ].map(([id, name, hosts, items]) => ({
      id, name, hosts, items, search: true,
      markers: '[data-explicit="true"], [data-sensitive="true"], [aria-label="Explicit content" i]',
      warning: /^(explicit content|adult content|sensitive content)$/i,
      flagged: d => d.is_explicit === true || d.is_sensitive === true,
    })),
    { id: 'twitter', name: 'Twitter / X', hosts: ['x.com', 'twitter.com'],
      items: 'article[data-testid="tweet"], article[role="article"]',
      markers: '[data-possibly-sensitive="true"], [aria-label="Content warning" i], [data-testid="sensitiveMediaWarning"]',
      warning: /^(sensitive content|content warning|the following media includes potentially sensitive content)/i,
      flagged: d => d.possibly_sensitive === true },
    { id: 'reddit', name: 'Reddit', hosts: ['reddit.com'],
      items: 'shreddit-post, [data-testid="post-container"], .thing.link',
      markers: '[nsfw]:not([nsfw="false"]), [data-nsfw="true"], [data-over18="true"], .over18, .nsfw-stamp, [data-testid="nsfw-tag"]',
      warning: /^(nsfw|mature content)$/i,
      flagged: d => d.over_18 === true || d.over18 === true },
    { id: 'tumblr', name: 'Tumblr', hosts: ['tumblr.com'], items: 'article, [data-post-id]',
      markers: '[data-is-nsfw="true"], .post_hidden_as_adult, .content-warning',
      warning: /^(this post has been hidden|hidden from dashboard|adult content|hidden for adult content)/i,
      flagged: d => d.is_nsfw === true },
    { id: 'mastodon', name: 'Mastodon', hosts: [], items: '.status, .status__wrapper',
      detect: doc => /mastodon/i.test(doc.querySelector('meta[name="generator"]')?.content || '') ||
        !!(doc.querySelector('#mastodon, #initial-state') && doc.querySelector('.status, .app-holder')),
      markers: '.media-spoiler, .media-gallery__item--hidden, .media-scrim, .status__content__spoiler, [data-sensitive="true"]',
      warning: /^(sensitive content|sensitive media|content warning)$/i,
      flagged: d => d.sensitive === true || typeof d.spoiler_text === 'string' && d.spoiler_text.trim() !== '' },
    { id: 'discord', name: 'Discord', hosts: ['discord.com'], items: '[id^="chat-messages-"], [data-list-item-id^="chat-messages"]',
      sensitive: item => query(item, 'img, video, [class*="attachment"], [class*="spoiler"]').some(node =>
        /blur\(/.test(node.style.filter || '') || node.isConnected && /blur\(/.test(getComputedStyle(node).filter)),
      markers: '[class*="hiddenExplicit"], [class*="explicitContentWarning"], [class*="spoilerContent"][class*="hidden"]',
      warning: /^(sensitive content|explicit content|spoiler)$/i, flagged: () => false },
    { id: 'instagram', name: 'Instagram', hosts: ['instagram.com'], items: 'article, [role="dialog"]',
      markers: '[aria-label="Sensitive content" i]', warning: /^sensitive content$/i, flagged: () => false },
    { id: 'facebook', name: 'Facebook', hosts: ['facebook.com'], items: '[role="article"], [data-pagelet^="FeedUnit"]',
      markers: '[aria-label="Graphic content" i], [aria-label="Sensitive content" i]',
      warning: /^(graphic content|sensitive content|violent or graphic content)$/i,
      flagged: d => typeof d.contentWarningText === 'string' && d.contentWarningText.trim() !== '' },
    { id: 'imgur', name: 'Imgur', hosts: ['imgur.com'], items: '.post, .Gallery-Content, .image, [data-post-id]',
      markers: '[data-has-mature="true"], .mature-content', warning: /^mature content$/i,
      flagged: d => d.has_mature === true },
  ];
  function forHost(hostname) {
    return definitions.find(site => site.hosts.some(host => hostname === host || hostname.endsWith('.' + host)));
  }
  function forDocument(doc, hostname) {
    return forHost(hostname) || definitions.find(site => site.detect?.(doc)) || null;
  }
  function searchURLs(item, ownOnly = false) {
    const urls = new Set();
    function add(raw, depth = 0) {
      if (!raw || depth > 3) return;
      try {
        const url = new URL(raw, item.baseURI);
        if (!['http:', 'https:'].includes(url.protocol)) return;
        urls.add(url.href);
        for (const key of ['imgurl', 'img_url', 'imgrefurl', 'mediaurl', 'url', 'q', 'u', 'uddg']) {
          const nested = url.searchParams.get(key);
          if (nested && /^https?:\/\//i.test(nested)) add(nested, depth + 1);
        }
        const yahoo = url.pathname.match(/\/RU=([^/]+)/);
        if (yahoo) add(decodeURIComponent(yahoo[1]), depth + 1);
      } catch { /* Invalid result metadata. */ }
    }
    function metadata(value, depth = 0) {
      if (!value || typeof value !== 'object' || depth > 8) return;
      for (const [key, child] of Object.entries(value)) {
        if (typeof child === 'string' && /^(murl|purl|img_href|url|image|source|original|.*_url)$/i.test(key)) add(child);
        else if (child && typeof child === 'object') metadata(child, depth + 1);
      }
    }
    for (const node of [item, ...(ownOnly ? [] : item.querySelectorAll('a[href], img, video, source, [data-lpage], [data-ou], [data-iurl], [data-bem], [m], [data-yamato-background]'))]) {
      for (const raw of backgroundURLs(node.getAttribute('data-yamato-background'))) add(raw);
      for (const name of ['href', 'src', 'poster', 'data-yamato-held-src', 'data-yamato-held-poster', 'data-lpage', 'data-ou', 'data-iurl']) add(node.getAttribute(name));
      for (const name of ['m', 'data-bem']) {
        const raw = node.getAttribute(name);
        if (raw && raw.length < 100000) try { metadata(JSON.parse(raw)); } catch { /* Not JSON. */ }
      }
    }
    return [...urls];
  }
  function backgroundURLs(value = '') {
    return [...(value || '').matchAll(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*))\s*\)/gi)]
      .map(match => match[1] ?? match[2] ?? match[3].trim());
  }
  function query(root, selector) {
    const result = [...root.querySelectorAll(selector)];
    const hosts = [root, ...(selector === '*' ? result : root.querySelectorAll('*'))];
    for (const host of hosts) if (host.shadowRoot) result.push(...query(host.shadowRoot, selector));
    return result;
  }
  function closestItem(node, site) {
    while (node) {
      const item = (site.search && node.closest?.(site.items.replace(', a:has(img)', ''))) || node.closest?.(site.items);
      if (item) return item;
      node = node.getRootNode?.().host;
    }
    return null;
  }
  function sensitive(item, site) {
    if (item.matches(site.markers) || query(item, site.markers).length) return true;
    // Restrict text matching to warning controls, never the body of a post.
    for (const node of query(item, 'button, [role="button"], [role="alert"], h1, h2, h3, [class*="warning" i]')) {
      if (site.warning.test(node.textContent.trim())) return true;
    }
    return !!site.sensitive?.(item);
  }
  function settings(value = {}) {
    const siteModules = {};
    for (const site of definitions) {
      siteModules[site.id] = value.enableSiteModules === false ? 'off' :
        ['jc', 'jce'].includes(value.siteModules?.[site.id]) ? value.siteModules[site.id] : value.siteModules?.[site.id] === 'off' ? 'off' : 'jc';
    }
    return { enableSiteModules: value.enableSiteModules !== false, mediaBlockMode: value.mediaBlockMode === 'jce' ? 'jce' : 'jc', siteModules };
  }
  return { definitions, forHost, forDocument, sensitive, settings, query, closestItem, searchURLs, backgroundURLs };
})();

// Network and DOM replacements share formats the receiving element can decode.
globalThis.yamatoJC = {
  sound: '/public/sounds/jc.ogg',
  image: '/public/assets/jc.png',
  video: '/public/assets/jc.webm',
  rules(condition, priority, firstId) {
    return [
      { types: ['image', 'sub_frame', 'object'], path: this.image },
      { types: ['media'], path: this.video },
    ].map(({ types, path }, index) => ({
      id: firstId + index, priority,
      action: { type: 'redirect', redirect: { extensionPath: path } },
      condition: { ...condition, resourceTypes: types.filter(type => condition.resourceTypes.includes(type)) },
    })).filter(rule => rule.condition.resourceTypes.length);
  },
};
// MAIN-world media hooks; parser requests can arrive before warnings.
(() => {
  const sites = globalThis.yamatoSites;
  const mediaSelector = 'img, video, audio, source, iframe, embed, object';
  // Use an image placeholder to avoid frame downloads.
  const blank = 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';
  const empty = blank + '#yamato-blocked';
  const blockedURLs = new Set();
  let enabled = false;
  let site;
  let busy = false;
  const nativeSet = Element.prototype.setAttribute;
  const nativeParse = JSON.parse;
  const nativeDispatch = EventTarget.prototype.dispatchEvent;
  const signal = element => {
    nativeSet.call(element, 'data-yamato-sensitive', 'true');
    nativeDispatch.call(element, new Event('yamato-sensitive', { bubbles: true }));
  };
  document.addEventListener('yamato-site-config', () => {
    site = sites.forDocument(document, location.hostname);
    enabled = !!site && document.documentElement?.getAttribute('data-yamato-site-enabled') === site.id;
    if (!enabled) blockedURLs.clear();
  });
  nativeDispatch.call(document, new Event('yamato-site-ready'));

  // Suppress errors while source checks are pending.
  document.addEventListener('error', event => {
    const element = event.target;
    if (element.hasAttribute?.('data-yamato-held-src') &&
        element.matches?.(mediaSelector) && !element.hasAttribute('data-yamato-approved') &&
        !element.hasAttribute('data-yamato-replacement')) event.stopImmediatePropagation();
  }, true);

  function inspect(data) {
    if (!enabled || !data || typeof data !== 'object') return data;
    const seen = new WeakSet();
    // Flags apply to descendants, never sibling posts.
    function visit(value, flagged = false, media = false, depth = 0) {
      if (!value || typeof value !== 'object' || seen.has(value) || depth > 40) return;
      seen.add(value);
      flagged ||= site.flagged(value);
      for (const key of Object.keys(value)) {
        const child = value[key];
        const isMedia = media || /^(media|media_attachments|extended_entities|entities|preview|images|image|video|videos|variants|thumbnail|thumbnails|streamingData|formats|adaptiveFormats|attachments|photos|contentRating|videoDetails)$/i.test(key);
        if (flagged && typeof child === 'string' &&
          (isMedia && /^(url|src|source|srcset|.*_url|.*Url)$/i.test(key) || /^(media_url_https|media_url|thumbnail_src|display_url|url_overridden_by_dest)$/i.test(key)) && /^https?:\/\//i.test(child)) {
          blockedURLs.add(child);
          if (blockedURLs.size > 5000) blockedURLs.delete(blockedURLs.values().next().value);
          value[key] = empty;
          nativeDispatch.call(document, new Event('yamato-sensitive-data'));
        } else if (child && typeof child === 'object') visit(child, flagged, isMedia, depth + 1);
      }

    }
    visit(data);
    return data;
  }
  JSON.parse = function (...args) { return inspect(Reflect.apply(nativeParse, this, args)); };
  const responseJSON = Response.prototype.json;
  Response.prototype.json = async function (...args) { return inspect(await Reflect.apply(responseJSON, this, args)); };
  // XHR responseType=json bypasses JSON.parse in many clients.
  const xhrResponse = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'response');
  if (xhrResponse?.get && xhrResponse.configurable) {
    Object.defineProperty(XMLHttpRequest.prototype, 'response', { ...xhrResponse, get() {
      const value = xhrResponse.get.call(this);
      return this.responseType === 'json' ? inspect(value) : value;
    } });
  }
  const attachShadow = Element.prototype.attachShadow;
  Element.prototype.attachShadow = function (...args) {
    const root = Reflect.apply(attachShadow, this, args);
    if (root.mode === 'open') nativeDispatch.call(this, new Event('yamato-shadow', { bubbles: true, composed: true }));
    return root;
  };
  function shouldBlock(element, value) {
    if (!enabled || busy || !element.matches(mediaSelector)) return false;
    if (element.hasAttribute('data-yamato-sensitive')) return true;
    const item = sites.closestItem(element, site);
    return blockedURLs.has(String(value)) || !!item && sites.sensitive(item, site);
  }
  function guard(element, value, name) {
    // Keep replacements when frameworks restore original sources.
    if (enabled && element.hasAttribute('data-yamato-replacement') && element.hasAttribute('data-yamato-sensitive')) {
      return element.getAttribute(name) || '';
    }
    // Hold sources until their result container is checked.
    if (enabled && !busy && site.search && element.matches(mediaSelector) &&
        !element.hasAttribute('data-yamato-replacement')) {
      // Frameworks often assign the same source again. Keep checked media in
      // place instead of navigating it through a placeholder and back.
      const held = element.getAttribute('data-yamato-held-' + name);
      if (held === String(value)) return element.getAttribute(name) || '';
      if (held === null && element.hasAttribute('data-yamato-checked') &&
          element.getAttribute(name) === String(value) && !shouldBlock(element, value)) return value;
      element.removeAttribute('data-yamato-approved');
      element.removeAttribute('data-yamato-checked');
      nativeSet.call(element, 'data-yamato-held-' + name, String(value));
      nativeDispatch.call(element, new Event('yamato-search-media', { bubbles: true, composed: true }));
      return blank + '#yamato-pending';
    }
    if (!shouldBlock(element, value)) return value;
    busy = true;
    try { signal(element); } finally { busy = false; }
    return empty;
  }
  Element.prototype.setAttribute = function (name, value) {
    if (/^(src|srcset|poster|data)$/i.test(name)) value = guard(this, value, name.toLowerCase());
    return nativeSet.call(this, name, value);
  };
  for (const [proto, names] of [
    [HTMLImageElement.prototype, ['src', 'srcset']], [HTMLMediaElement.prototype, ['src']],
    [HTMLVideoElement.prototype, ['poster']], [HTMLSourceElement.prototype, ['src', 'srcset']],
    [HTMLIFrameElement.prototype, ['src']], [HTMLEmbedElement.prototype, ['src']], [HTMLObjectElement.prototype, ['data']],
  ]) {
    for (const name of names) {
      const descriptor = Object.getOwnPropertyDescriptor(proto, name);
      if (!descriptor?.set || !descriptor.configurable) continue;
      Object.defineProperty(proto, name, { ...descriptor, set(value) { descriptor.set.call(this, guard(this, value, name)); } });
    }
  }
})();
